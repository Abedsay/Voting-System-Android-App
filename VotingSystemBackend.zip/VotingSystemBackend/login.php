<?php
    require_once 'connection.php';
    $user=$_GET['username'];
    $pass=$_GET['password'];

    $query="Select * from users where username='$user' and password='$pass'";
    $result=mysqli_query($con, $query);
    $nbrows=mysqli_num_rows($result);
    if($nbrows==1)
    {
        echo "success";
    }
    else{
        echo "failed to login";
    }   
?>