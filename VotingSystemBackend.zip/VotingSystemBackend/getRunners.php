<?php
    require_once 'connection.php';

    $clubName = isset($_GET['clubName']) ? $_GET['clubName'] : '';

    $sql = "SELECT `runnerName`, `clubName`, `skill1`, `skill2`, `skill3`, `description` 
        FROM `runners` 
        WHERE `clubName` = ?";
    $stmt = $con->prepare($sql);
    $stmt->bind_param("s", $clubName);
    $stmt->execute();

    $result = $stmt->get_result();
    $runners = [];
    while ($row = $result->fetch_assoc()) {
        $runners[] = $row;
    }

    echo json_encode($runners);

    $stmt->close();
    $con->close();
?>
