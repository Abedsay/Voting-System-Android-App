<?php
    require_once 'connection.php';
    $user=$_GET['username'];
    $pass=$_GET['password'];
    $name=$_GET['name'];

    $query = "SELECT * FROM users WHERE username='$user'";
    $result=mysqli_query($con, $query);
    $nbrows=mysqli_num_rows($result);
    
    if ($nbrows>0) {
        echo "user already exists";
    }
    else {
        $query2 = "INSERT INTO users (username, name, password) VALUES (?, ?, ?)";
        $stmt = mysqli_prepare($con, $query2);
        
        mysqli_stmt_bind_param($stmt, 'sss', $user, $name, $pass);
        
        if (mysqli_stmt_execute($stmt)) {
            echo "User registered successfully";
        } else {
            echo "Error: " . mysqli_error($con);
        }

        mysqli_stmt_close($stmt);        
    }

?>