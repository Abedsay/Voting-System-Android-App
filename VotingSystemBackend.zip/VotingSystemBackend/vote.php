<?php
require_once 'connection.php';

$response = array();

if ($_SERVER['REQUEST_METHOD'] === 'GET') {
    $voterName = isset($_GET['voterName']) ? $_GET['voterName'] : '';
    $clubName = isset($_GET['clubName']) ? $_GET['clubName'] : '';
    $votedFor = isset($_GET['votedFor']) ? $_GET['votedFor'] : '';

    if (!empty($voterName) && !empty($clubName) && !empty($votedFor)) {
        $stmt = $con->prepare("SELECT * FROM voters WHERE voterName = ? AND clubName = ?");
        $stmt->bind_param("ss", $voterName, $clubName);
        $stmt->execute();
        $result = $stmt->get_result();

        if ($result->num_rows > 0) {
            $response['message'] = "You have already voted for this club!";
        } else {
            $stmt = $con->prepare("INSERT INTO voters (voterName, clubName, votedFor) VALUES (?, ?, ?)");
            $stmt->bind_param("sss", $voterName, $clubName, $votedFor);

            if ($stmt->execute()) {
                $response['message'] = "Vote registered successfully!";
            } else {
                $response['message'] = "Error: " . $stmt->error;
            }
        }

        $stmt->close();
    } else {
        $response['message'] = "Error: Missing parameters!";
    }
}

echo json_encode($response);

$con->close();
?>
