<?php
    require_once 'connection.php';
   
    $runnerName = $_GET['name'];
    $clubName = $_GET['clubName'];
    $skill1 = $_GET['skill1'];
    $skill2 = $_GET['skill2'];
    $skill3 = $_GET['skill3'];
    $description = $_GET['description'];

    $query = "INSERT INTO `runners` (`runnerName`, `clubName`, `skill1`, `skill2`, `skill3`, `description`) 
            VALUES ('$runnerName', '$clubName', '$skill1', '$skill2', '$skill3', '$description')";

    if (mysqli_query($con, $query)) {
        echo "Runner added successfully";
    } else {
        echo "Error: " . mysqli_error($con);
    }
?>
