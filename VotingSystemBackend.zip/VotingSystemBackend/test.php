<?php
if (isset($_GET['clubName'])) {
    echo "clubName: " . $_GET['clubName'];
} else {
    echo "No clubName provided";
}
?>