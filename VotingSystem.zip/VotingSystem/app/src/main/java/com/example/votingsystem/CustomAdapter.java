
package com.example.votingsystem;

import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.BaseAdapter;
import android.widget.TextView;
import org.json.JSONArray;
import org.json.JSONObject;


public class CustomAdapter extends BaseAdapter {
    private final Context context;
    private final JSONArray data;
    private final LayoutInflater inflater;
    private final String voterName;
    private final String clubName;

    public CustomAdapter(Context context, JSONArray data, String voterName, String clubName) {
        this.context = context;
        this.data = data;
        this.voterName = voterName;
        this.clubName = clubName;
        this.inflater = LayoutInflater.from(context);
    }

    @Override
    public int getCount() {
        return data.length();
    }

    @Override
    public Object getItem(int position) {
        return data.optJSONObject(position);
    }

    @Override
    public long getItemId(int position) {
        return position;
    }

    @Override
    public View getView(int position, View convertView, ViewGroup parent) {
        View rowView = inflater.inflate(R.layout.row, parent, false);

        TextView fullName = rowView.findViewById(R.id.textView12);
        TextView skill1 = rowView.findViewById(R.id.textView15);
        TextView skill2 = rowView.findViewById(R.id.textView16);
        TextView skill3 = rowView.findViewById(R.id.textView18);
        TextView description = rowView.findViewById(R.id.textView19);

        JSONObject runner = data.optJSONObject(position);
        if (runner != null) {
            String nameWithRole = runner.optString("runnerName");
            fullName.setText(nameWithRole);

            skill1.setText(runner.optString("skill1"));
            skill2.setText(runner.optString("skill2"));
            skill3.setText(runner.optString("skill3"));

            description.setText(runner.optString("description"));

        }

        return rowView;
    }


}
