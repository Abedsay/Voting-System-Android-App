package com.example.votingsystem;

import android.os.Bundle;
import android.view.MenuItem;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Spinner;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;

import com.android.volley.Request;
import com.android.volley.Response;
import com.android.volley.toolbox.StringRequest;
import com.android.volley.toolbox.Volley;

import com.example.votingsystem.databinding.ActivityRunningBinding;

public class Running extends AppCompatActivity {

    private ActivityRunningBinding binding;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

        binding = ActivityRunningBinding.inflate(getLayoutInflater());
        setContentView(binding.getRoot());

        setSupportActionBar(binding.toolbar);

        if (getSupportActionBar() != null) {
            getSupportActionBar().setDisplayHomeAsUpEnabled(true);
        }

        EditText nameEditText = findViewById(R.id.editTextText);
        Spinner clubSpinner = findViewById(R.id.spClub);
        EditText skill1EditText = findViewById(R.id.skill1);
        EditText skill2EditText = findViewById(R.id.skill2);
        EditText skill3EditText = findViewById(R.id.skill3);
        EditText descEditText = findViewById(R.id.desc);
        Button submitButton = findViewById(R.id.btnSubmit);

        submitButton.setOnClickListener(v -> {
            String runnerName = nameEditText.getText().toString();
            String clubName = clubSpinner.getSelectedItem().toString();
            String skill1 = skill1EditText.getText().toString();
            String skill2 = skill2EditText.getText().toString();
            String skill3 = skill3EditText.getText().toString();
            String description = descEditText.getText().toString();

            if (runnerName.isEmpty() || clubName.isEmpty() || skill1.isEmpty() || skill2.isEmpty() || skill3.isEmpty() || description.isEmpty()) {
                Toast.makeText(Running.this, "Please fill all fields", Toast.LENGTH_SHORT).show();
            } else {
                submitRunner(runnerName, clubName, skill1, skill2, skill3, description);
            }
        });
    }

    private void submitRunner(String runnerName, String clubName, String skill1, String skill2, String skill3, String description) {
        String url = "http://10.0.2.2/VotingSystemBackend/run.php?name=" + runnerName + "&clubName=" + clubName + "&skill1=" + skill1 + "&skill2=" + skill2 + "&skill3=" + skill3 + "&description=" + description;

        StringRequest stringRequest = new StringRequest(Request.Method.GET, url,
                new Response.Listener<String>() {
                    @Override
                    public void onResponse(String response) {
                        Toast.makeText(Running.this,  response, Toast.LENGTH_LONG).show();
                        if (response.contains("Runner added successfully")) {
                            finish();
                        }
                    }
                },
                error -> {
                    Toast.makeText(Running.this, "Error: " + error.getMessage(), Toast.LENGTH_LONG).show();
                });

        Volley.newRequestQueue(this).add(stringRequest);
    }

    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        if (item.getItemId() == android.R.id.home) {
            onBackPressed();
            return true;
        }
        return super.onOptionsItemSelected(item);
    }
}
