package com.example.votingsystem;

import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ListView;
import android.widget.Spinner;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;

import com.android.volley.Request;
import com.android.volley.RequestQueue;
import com.android.volley.Response;
import com.android.volley.VolleyError;
import com.android.volley.toolbox.JsonArrayRequest;
import com.android.volley.toolbox.JsonObjectRequest;
import com.android.volley.toolbox.Volley;

import org.json.JSONArray;
import org.json.JSONObject;

public class Voting extends AppCompatActivity {

    private ListView listView;
    private RequestQueue queue;
    private Spinner spinner2;
    private Button btnVote;
    private EditText username;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_voting);

        listView = findViewById(R.id.listView);
        Spinner spinner = findViewById(R.id.spinner);

        queue = Volley.newRequestQueue(this);

        btnVote = findViewById(R.id.button);
        spinner2 = findViewById(R.id.spinner2);
        username = findViewById(R.id.btnConfirm);

        spinner.setOnItemSelectedListener(new AdapterView.OnItemSelectedListener() {
            @Override
            public void onItemSelected(AdapterView<?> parent, View view, int position, long id) {
                String selectedClub = parent.getItemAtPosition(position).toString();
                fetchRunners(selectedClub);
            }

            @Override
            public void onNothingSelected(AdapterView<?> parent) {
            }
        });

        btnVote.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                String voterName = username.getText().toString().trim();
                String clubName = spinner.getSelectedItem().toString();
                String votedFor = spinner2.getSelectedItem().toString();

                if (voterName.isEmpty()) {
                    Toast.makeText(Voting.this, "Please enter a valid username.", Toast.LENGTH_SHORT).show();
                    return;
                }

                String url = "http://10.0.2.2/VotingSystemBackend/vote.php?voterName=" + voterName
                        + "&clubName=" + clubName + "&votedFor=" + votedFor;

                Log.d("Voting", "Vote URL: " + url);

                JsonObjectRequest jsonObjectRequest = new JsonObjectRequest(Request.Method.GET, url, null,
                        new Response.Listener<JSONObject>() {
                            @Override
                            public void onResponse(JSONObject response) {
                                try {
                                    if (response.has("message")) {
                                        String message = response.getString("message");
                                        Toast.makeText(Voting.this, message, Toast.LENGTH_SHORT).show();
                                    } else {
                                        Toast.makeText(Voting.this, "Unexpected response format", Toast.LENGTH_SHORT).show();
                                    }
                                } catch (Exception e) {
                                    e.printStackTrace();
                                    Toast.makeText(Voting.this, "Error parsing response", Toast.LENGTH_SHORT).show();
                                }
                            }
                        },
                        new Response.ErrorListener() {
                            @Override
                            public void onErrorResponse(VolleyError error) {
                                Toast.makeText(Voting.this, "Error: " + error.getMessage(), Toast.LENGTH_LONG).show();
                            }
                        });

                queue.add(jsonObjectRequest);
            }
        });


    }


    private void fetchRunners(String clubName) {
        String voterName = "John Doe";
        String url = "http://10.0.2.2/VotingSystemBackend/getRunners.php?clubName=" + clubName;

        JsonArrayRequest jsonArrayRequest = new JsonArrayRequest(Request.Method.GET, url, null,
                new Response.Listener<JSONArray>() {
                    @Override
                    public void onResponse(JSONArray response) {

                        if (response == null || response.length() == 0) {
                            Toast.makeText(Voting.this, "No runners found", Toast.LENGTH_SHORT).show();
                            return;
                        }

                        String[] runnerNames = new String[response.length()];
                        try {
                            for (int i = 0; i < response.length(); i++) {
                                Log.d("Voting", "Runner JSON Object: " + response.getJSONObject(i).toString());

                                if (response.getJSONObject(i).has("runnerName")) {
                                    runnerNames[i] = response.getJSONObject(i).getString("runnerName");
                                } else {
                                    runnerNames[i] = "Unknown";
                                }
                            }

                            CustomAdapter adapter = new CustomAdapter(Voting.this, response, voterName, clubName);
                            listView.setAdapter(adapter);

                            Spinner spinner2 = findViewById(R.id.spinner2);
                            ArrayAdapter<String> spinnerAdapter = new ArrayAdapter<>(Voting.this,
                                    android.R.layout.simple_spinner_item, runnerNames);
                            spinnerAdapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
                            spinner2.setAdapter(spinnerAdapter);

                        } catch (Exception e) {
                            e.printStackTrace();
                            Toast.makeText(Voting.this, "Error parsing response", Toast.LENGTH_SHORT).show();
                        }
                    }
                },
                new Response.ErrorListener() {
                    @Override
                    public void onErrorResponse(VolleyError error) {
                        Toast.makeText(Voting.this, "Error: " + error.getMessage(), Toast.LENGTH_LONG).show();
                    }
                });

        queue.add(jsonArrayRequest);
    }




}
